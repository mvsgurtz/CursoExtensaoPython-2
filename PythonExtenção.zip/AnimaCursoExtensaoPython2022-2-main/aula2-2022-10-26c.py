#Exemplo de laço

#Se eu quisesse exibir números de 1 a 10?
print("Aqui mostramos de maneira 'rústica'")
print("1")
print("2")
print("3")
print("4")
print("5")
print("6")
print("7")
print("8")
print("9")
print("10")

print("Aqui é do jeito certo...")
numero = 1
print(numero)
numero = numero + 1
print(numero)